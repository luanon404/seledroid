class Keys:
	ENTER = 66