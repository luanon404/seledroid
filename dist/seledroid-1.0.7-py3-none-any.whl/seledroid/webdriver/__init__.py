from .chrome.webdriver import WebDriver as Chrome
from .remote.remote_connection import RemoteConnection

__version__ = "1.0.0"